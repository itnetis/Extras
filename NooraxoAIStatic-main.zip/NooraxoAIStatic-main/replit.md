# Nooraxo AI - AI Tools Hub

## Overview
A landing page for "Nooraxo AI" - an AI tools hub and social media marketing platform with an AI-powered customer support chatbot. The site showcases AI tools, services, pricing plans, and community features with WhatsApp integration for orders.

## Recent Changes
- AI Tools section now loads dynamically from `public/tools-data.js` — edit that file to add/remove/change tools
- Mobile menu redesigned as a centered modal popup (outside header to avoid z-index stacking issues)
- Separate desktop-menu (inline in header) and menu-modal (outside header) for mobile
- WhatsApp button always visible; AI chatbot button appears only on scroll (300px threshold)
- Fixed horizontal scroll on mobile (overflow-x: hidden on html+body)
- Added Services section with Social Media Marketing, AI Tools Subscription, and AI Credits System
- Fixed popup readability in light mode
- Updated hero headline to "AI Tools and Social Media Marketing in One Place"
- Fixed icon loading after publishing (service worker network-first strategy)
- Switched chatbot from AIML to Hugging Face free tier (SambaNova provider, Meta-Llama-3.1-8B-Instruct model)
- Fixed mobile responsiveness across all sections

## Project Architecture
- **Type**: Express server serving static files + API
- **Server**: `server.js` - Express on port 5000
- **Static files**: `public/` folder (HTML, CSS, JS, icons)
- **API**: `/api/chat` endpoint for AI chatbot (POST)
- **Vercel**: `api/chat.js` serverless function + `vercel.json` config
- **PWA**: service-worker.js and manifest.json

## Page Sections
- Hero, Features, AI Tools, **Services**, Pricing, FAQ, Community/Reviews
- Services: Social Media Marketing, AI Tools Subscription, AI Credits System

## Key Files
- `server.js` - Express server (Replit)
- `api/chat.js` - Vercel serverless function
- `vercel.json` - Vercel deployment config
- `public/index.html` - Main landing page with chatbot widget
- `public/style.css` - All styles (dark/light theme, mobile responsive)
- `public/tools-data.js` - AI Tools data (edit this to add/remove/update tools)
- `public/service-worker.js` - PWA caching (network-first strategy)
- `public/manifest.json` - PWA manifest

## Vercel Deployment
1. Push to GitHub
2. Connect repo to Vercel
3. Set HF_TOKEN environment variable in Vercel
4. Deploy (auto-detects from vercel.json)

## Environment Variables
- `HF_TOKEN` - Hugging Face API token (free tier) for AI chatbot
