const AI_TOOLS = [
  {
    icon: "fa-solid fa-robot",
    name: "Veo 3.1 Ultra",
    badgeIcon: "fa-solid fa-bolt",
    description: "Next-level human like AI videos"
  },
  {
    icon: "fa-solid fa-microphone",
    name: "ElevenLabs Voice AI",
    badgeIcon: "fa-solid fa-headphones",
    description: "Realistic voice generation for your projects"
  },
  {
    icon: "fa-solid fa-image",
    name: "AI Image Generator",
    badgeIcon: "fa-solid fa-palette",
    description: "Create stunning AI-generated images instantly"
  },
  {
    icon: "fa-solid fa-magic",
    name: "Prompt2Voice Panel",
    badgeIcon: "fa-solid fa-comment",
    description: "Convert text prompts to natural voice outputs"
  }
];
