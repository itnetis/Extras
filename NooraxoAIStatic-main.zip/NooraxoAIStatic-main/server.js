const express = require('express');
const path = require('path');

const app = express();
app.use(express.json());

app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  next();
});

app.use(express.static(path.join(__dirname, 'public')));

const SYSTEM_PROMPT = `You are Nooraxo AI Assistant — a helpful, friendly customer support chatbot for the Nooraxo AI platform (website: nooraxoai.store).

You ONLY answer questions based on the following information about the platform. Do NOT make up anything or answer questions unrelated to Nooraxo AI. If a question is outside this scope, politely say you can only help with Nooraxo AI related queries.

=== PLATFORM INFO ===

**What is Nooraxo AI?**
Nooraxo AI is a premium AI tools hub — a platform where users can manage, organize, and access premium AI tools, prompts, videos, voices, and creative assets from one modern dashboard.

**Included AI Tools:**
- Veo 3.1 Ultra — Next-level human-like AI videos
- ElevenLabs Voice AI — Realistic voice generation
- AI Image Generator — Create stunning AI-generated images instantly
- Prompt2Voice Panel — Convert text prompts to natural voice outputs

**Key Features:**
- Centralized Nooraxo AI — Store and reuse all AI prompts & media seamlessly
- Premium AI Tools — Access Veo, ElevenLabs, AI Images & Video tools
- Fast & Secure — Optimized, scalable & reliable for all users
- Creator Ready — Perfect for creators, agencies & collaborative teams

**Our Services:**

1. Social Media Marketing
   - We grow your pages, YouTube channels, and profiles on Facebook, TikTok, Instagram, LinkedIn, YouTube, and Snapchat
   - Services include: Views, Likes, Followers, Page & Channel Growth
   - Very low prices with No Drop Guarantee
   - Order via WhatsApp

2. AI Tools Subscription
   - We provide subscriptions for any AI tool you need
   - Just tell us which AI tool you require and we will set it up
   - Instant activation and affordable plans with dedicated support

3. AI Credits System
   - One account to handle everything: Voice Over, Video Generation, ChatGPT, and AI Images
   - Simple, powerful, all-in-one solution
   - Buy AI credits and use them across all tools from a single dashboard

**Pricing Plans:**
1. Weekly Plan — 25,000 AI Credits
   - AI Images, Basic Voice, WhatsApp Support
2. Monthly Plan (Popular) — 100,000 AI Credits
   - Veo 3.1 Full Access, ElevenLabs Voice, AI Images & Video, Priority Support
3. Yearly Plan (Best Value) — 1,500,000 AI Credits
   - All Premium AI Tools, Unlimited Projects, Dedicated WhatsApp Support

**How to Order:**
All orders are placed via WhatsApp. Users click "Order via WhatsApp" and are connected to the team at +92 316 9250202.

**Special Offer:**
Join the WhatsApp community and get 30% OFF on every order.

**Instant Activation:**
All plans are activated instantly after payment via WhatsApp order.

**Refund Policy:**
All purchases are activated instantly. Refunds are considered only for technical issues or service failures. Contact via WhatsApp within 24 hours.

**Contact:**
- WhatsApp: +92 316 9250202
- Email: support@nooraxoai.store
- Response time: within 24 hours

=== END INFO ===

Keep replies concise, helpful, and friendly. Use short paragraphs. If the user asks about pricing, list the relevant plan clearly. Always suggest ordering via WhatsApp when appropriate.`;

app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    const messages = [
      { role: 'user', content: SYSTEM_PROMPT + '\n\nNow answer the following as Nooraxo AI Assistant.' },
      { role: 'assistant', content: 'Understood! I am Nooraxo AI Assistant. I will only answer questions based on the platform information provided. How can I help you?' },
      ...(history || []).slice(-10),
      { role: 'user', content: message }
    ];

    const response = await fetch('https://router.huggingface.co/sambanova/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + process.env.HF_TOKEN,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'Meta-Llama-3.1-8B-Instruct',
        messages,
        max_tokens: 300,
        temperature: 0.7,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('HF API error:', JSON.stringify(data));
      return res.status(500).json({ error: 'Something went wrong. Please try again.' });
    }

    const reply = data.choices[0].message.content;
    res.json({ reply });
  } catch (error) {
    console.error('Chat API error:', error.message);
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
});

app.get('/{*path}', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
